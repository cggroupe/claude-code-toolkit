# Schema cg-design — Taxonomie & Conventions

> Ground truth : règles de classification, conventions naming, champs canoniques.

---

## 1. Marques (`brands/<id>/brand.json`)

| Champ | Type | Obligatoire | Description |
|---|---|---|---|
| `id` | string | ✅ | Identifiant kebab-case (autaf) |
| `name` | string | ✅ | Nom commercial complet |
| `shortName` | string | | Acronyme |
| `domain` | string | ✅ | Domaine principal (autaf.fr) |
| `tagline` | string | ✅ | Slogan court 2-5 mots |
| `longTagline` | string | | Slogan long contextuel |
| `valueProp` | string | ✅ | Proposition de valeur 1-2 phrases |
| `colors` | object | ✅ | `primary`, `accent`, `darkBg`, `lightBg`, `textOnPrimary`, `textOnAccent` (hex) |
| `fonts` | object | ✅ | `display`, `body`, `mono` (noms de famille) |
| `logo` | object | ✅ | `svg` ou `png` (chemin relatif au dossier brand) |
| `tone` | string | ✅ | Description ton de communication |
| `icpExamples` | array | ✅ | Liste d'ICP réalistes |
| `stats` | object | | KPIs marque (chiffres réels) |
| `services` | array | | Liste services |
| `ctas` | object | | CTAs par persona |

---

## 2. Formats supportés (`templates/<format>/`)

| Format dir | Dimensions | Usage principal |
|---|---|---|
| `ig-portrait-1080-1350` | 1080×1350 (4:5) | **Instagram Ads + LinkedIn Ads portrait** ⭐ format optimal pour les feeds |
| `ig-square-1080` | 1080×1080 (1:1) | Posts IG/LinkedIn carrés (à coder) |
| `ig-story-1080-1920` | 1080×1920 (9:16) | Stories IG/Facebook + Reels covers (à coder) |
| `linkedin-landscape-1200-627` | 1200×627 | LinkedIn paysage (article shares) (à coder) |
| `tiktok-cover-1080-1920` | 1080×1920 (9:16) | Couvertures TikTok (à coder) |

**Note** : seul `ig-portrait-1080-1350` est codé pour le moment. Les autres ont leur dimensions enregistrées dans `src/render.js` (objet `FORMATS`) — il suffit d'ajouter des `.html` dans le bon dossier pour les rendre.

---

## 3. Convention naming templates

```
templates/<format>/<brand>-<index>-<persona>.html
```

Exemples :
- `autaf-01-artisans.html` → AUTAF, design n°1, cible artisans
- `autaf-84-blueprint-platrerie-1.html` → AUTAF, carrousel DTU plâtrerie slide 1 (style navy)

L'output PNG ajoute le format en suffixe :
```
output/<brand>-<index>-<persona>__<format>.png
```

Exemple : `autaf-01-artisans__ig-portrait-1080-1350.png`

---

## 4. Patterns esthétiques (3 validés)

| Pattern | Caractéristiques |
|---|---|
| `stamp-punchy` | Fond couleur signature dominant, headline énorme uppercase 96-124px, mot-clef « stamped » rotated -2° avec ombre, bandeau diagonal en couleur secondaire, stats row + CTA pill |
| `editorial-premium` | Fond foncé profond, gradient radial subtle, grid overlay, headline avec line-through accent + mot-clef colorisé, copy 2-3 lignes, CTA flat |
| `data-driven` | Split 2 zones (clair + foncé), highlight marker sur mot-clef, big number énorme, tags pills, CTA + signature |

Voir notes détaillées : [pattern-stamp-punchy](notes/pattern-stamp-punchy.md), [pattern-editorial-premium](notes/pattern-editorial-premium.md), [pattern-data-driven](notes/pattern-data-driven.md).

---

## 5. Stack technique invariants

- **Fonts** : Inter Display + Inter via `@font-face file:///usr/share/fonts/opentype/inter/` (déjà installées système). Ne pas dépendre de Google Fonts (pas de réseau dans Puppeteer, latence).
- **Logos** : SVG inline AUTAF (control fill via CSS), polices `file:///opt/stack/cg-design/brands/autaf/fonts/` montées localement.
- **Effets premium 2026** : SVG noise grain via data-URI, gradients radiaux ellipse, mix-blend-mode overlay/multiply, clip-path polygon, grid overlay subtle (60-90px), highlight marker sur mot-clef.
- **Render** : `deviceScaleFactor: 2` (retina), `--font-render-hinting=none` pour typo nette.
- **Coût** : 0 €/mois, tout local sur le VPS.

---

## 6. Pièges connus (à ne pas reproduire)

1. **Bandeau diagonal `clip-path`** peut couper le texte du bloc parent → laisser ≥80px de marge.
2. **Tagline en rotation -90deg** = mauvaise idée, chevauche le texte → préférer signature horizontale.
3. **Big number font-size > 200px** déborde si nombre à 4+ chiffres → cap à 156-180px ou réduire la longueur.
4. **`white-space: nowrap`** obligatoire sur les digits pour éviter les retours ligne involontaires.
5. **Polices** : ne pas utiliser de noms système non installés (toujours `fc-list | grep <font>` avant).
