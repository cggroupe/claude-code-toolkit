# Pattern · data-driven

**Type** : pattern esthétique
**Validé** : 2026-05-08 sur AUTAF agences d'intérim
**Quand l'utiliser** : partenariats institutionnels, B2B avec un argument chiffré décisif, dossiers presse

---

## Caractéristiques

- **Split 2 zones** verticales : haut clair (≈55%) + bas foncé (≈45%)
- **Zone haute** : fond clair (#FAFAF7 / #F8F4ED), grid subtle, eyebrow mono, headline 88-96px avec **highlight marker** sur mot-clef (background jaune fluo en gradient padding 60% high)
- **Tags pills** (5-6 max) entre la zone claire et foncée : background blanc + border subtle, dot couleur signature
- **Zone basse** : fond foncé profond (#241B5D / #0A3D0A), avec gradient radial accent
- **Big number** énorme dans la zone foncée : digits 156-200px weight 800 + unit 44-76px à côté en couleur accent
- **Caption** 19-22px weight 500 sous le big number (max-width 800px, line-height 1.45)
- **CTA flat rectangulaire** + signature à droite (domain en gras, sub-tagline en italic ou regular)

## Cibles habituelles

- AUTAF agences d'intérim BTP (×4 votre sourcing)
- Investisseurs, partenaires institutionnels
- Presse économique (Les Echos, Capital, Challenges)

## Variantes selon ton

- **Tech/SaaS** (AUTAF) : pills « API REST », « Notation vérifiée », accent jaune signature, ton growth

## Code template canonique

- `templates/ig-portrait-1080-1350/autaf-03-agences.html` (tech bleu marine + jaune)

## Pièges spécifiques

- **Highlight marker** : `background: linear-gradient(180deg, transparent 60%, <accent> 60%)` pour avoir l'effet surligneur jaune type fluo Stabilo.
- **Big number** : si nombre > 4 caractères, **réduire font-size à 156px** et `white-space: nowrap` obligatoire.
- **Layout digits + unit** : `display: flex; align-items: baseline; gap: 22px` — sinon désaligné.
- **Footer chevauchement** : la zone basse doit avoir ≥420px de hauteur pour caser num-label + num-display + caption + footer sans collision.
- **Tags overflow** : si plus de 5 tags, ils wrappent — accepter ou réduire à 4-5.
