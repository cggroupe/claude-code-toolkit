# Note · stack-foundations

**Type** : foundations
**Created** : 2026-05-08
**Status** : ✅ validé production

---

## Stack technique

| Couche | Outil | Version | Pourquoi ce choix |
|---|---|---|---|
| Render engine | Puppeteer | 24.38 | Rendu CSS moderne complet (gradients, blurs, masks, mix-blend-mode) |
| Templating | HTML/CSS pure | — | Pas de complexité Handlebars/JSX, source de vérité = le HTML |
| Polices | Inter + Inter Display | 4.x | Installées système, tous les poids 100-900 |
| Server | Node.js plain HTTP | 20.20 | Pas d'Express, pas de surcouche, dashboard fait main |
| Service | systemd | — | Auto-restart, logs centralisés, démarrage au boot |
| Port | 8940 | — | Réservé cg-design dans le plan d'allocation VPS |

## Pourquoi pas Satori / Bannerbear / Canva

- **Satori** : limité côté CSS moderne (pas de mix-blend-mode, certains gradients, masks). On a besoin du contrôle total.
- **Bannerbear / Placid** : SaaS 49-149 €/mois × 6 marques = couteux ; lock-in templates ; pas de personnalisation au design level.
- **Canva Connect API** : Autofill = Canva Enterprise uniquement (devis 2-30k €/an). Hors budget.
- **Open Design (nexu-io)** : alternative valable, à creuser si on veut industrialiser plus loin (71 design systems pré-construits). Mais pour l'instant la stack maison fait le job à 0 €/mois.

## Architecture fichiers

```
/opt/stack/cg-design/
├── package.json            scripts npm (render, serve)
├── README.md               guide CLI/API rapide
├── CLAUDE.md               instructions Claude pour générer un design
├── log.md                  journal opérations
├── brands/<brand>/         brand.json + assets (logo, polices custom)
├── templates/<format>/     un .html par design (1 seul format codé : ig-portrait-1080-1350)
├── src/
│   ├── render.js           CLI batch render
│   └── server.js           HTTP server port 8940 (dashboard + statique)
├── output/                 PNGs générés
└── wiki/                   pattern Karpathy
```

## Workflow pour générer un nouveau design

1. Choisir le pattern esthétique cible : `stamp-punchy`, `editorial-premium`, `data-driven`.
2. Copier un template existant de la même famille (ex. `autaf-01-artisans.html` pour stamp-punchy).
3. Adapter :
   - Couleurs : utiliser celles du `brand.json`
   - Logo : référencer celui dans `brands/<brand>/`
   - Headline : `<h1>` adapté à la cible
   - Stats / CTA : adapter au persona
4. Render : `node src/render.js --template <nouveau-nom>`
5. Vérifier sur le dashboard `http://147.93.52.70:8940/`

## Points sensibles à respecter

- **Toujours `position: absolute` pour les blocs principaux** (pas de flex layout du body, sinon overflow).
- **Toujours fixer `width:1080px; height:1350px; overflow:hidden` sur html/body**.
- **Toujours déclarer `@font-face` avec `file:///`** (Puppeteer pas de réseau par défaut).
- **Toujours `deviceScaleFactor: 2`** pour qualité retina.
- **Toujours `--font-render-hinting=none`** dans args Puppeteer pour typo nette.

## Limitations actuelles

- Un seul format codé (`ig-portrait-1080-1350`) — extension prévue formats carré, story, paysage, TikTok cover.
- Pas d'API `POST /generate` dynamique pour l'instant — le rendu est CLI uniquement (`node src/render.js`).
- Pas de templating de variables : chaque design est un fichier HTML autonome. Si on veut paramétrer (« génère 50 variations »), il faudra ajouter Handlebars ou un template engine.

Voir aussi : [pattern-stamp-punchy](pattern-stamp-punchy.md), [pattern-editorial-premium](pattern-editorial-premium.md), [pattern-data-driven](pattern-data-driven.md).
