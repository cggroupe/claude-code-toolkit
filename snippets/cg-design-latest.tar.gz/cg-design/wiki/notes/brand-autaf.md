# Brand · AUTAF

**Type** : marque
**Status** : ✅ 3 templates IG portrait validés (08/05/2026)
**Filiation** : marque de WorkRepublic
**Domaine** : autaf.fr

---

## Charte graphique

| Élément | Valeur |
|---|---|
| Couleur primaire | `#241B5D` Bleu marine AUTAF |
| Couleur accent | `#FFE72B` Jaune signature AUTAF |
| Fond foncé | `#0F0A35` (gradient bleu marine -> noir) |
| Fond clair | `#FAFAF7` (cassé pour patterns data-driven) |
| Police display | Inter Display |
| Police corps | Inter |
| Logo | SVG inline (`brands/autaf/logo.svg`), fill controllable |

## Tagline canonique

- **Court** : « Par des pros, pour des pros »
- **Long** : « Bien plus qu'une plateforme, une communauté »

## ICP & ton

| ICP | Ton | Pattern recommandé |
|---|---|---|
| Artisans (plombiers, électriciens, maçons, carreleurs) | Tutoiement, terrain, punchy | stamp-punchy fond jaune |
| PME du BTP, professionnels | Vouvoiement, premium éditorial | editorial-premium fond marine |
| Agences d'intérim BTP | Vouvoiement, data-driven | data-driven split blanc/marine |
| Sous-traitants, conducteurs de travaux | Vouvoiement, ROI | editorial-premium ou data-driven |

## Stats à utiliser

- **12 400+** artisans actifs
- **24h** délai première mission
- **0 €** inscription gratuite

## Templates existants

- `autaf-01-artisans.html` — pattern stamp-punchy, headline « T'AS UN MARTEAU. ON A 3 CHANTIERS. »
- `autaf-02-professionnels.html` — pattern editorial-premium, headline « Sous-effectif (rayé). Carnet plein. Renforts en 48h. »
- `autaf-03-agences.html` — pattern data-driven, headline « Votre vivier candidats BTP, multiplié par 4. » *(angle "réseau ×4" — à utiliser comme pub partenariat institutionnel)*
- `autaf-04-agences-placement.html` — pattern stamp-punchy, headline « VOS PROFILS. NOS CHANTIERS. EN 1 CLIC. » *(angle placement intérimaires sur chantiers, marketplace + matching équipe ; cible agences ETT BTP)*
- `autaf-05-agences-qualite.html` — pattern editorial-premium, headline « Plus de déclaratif (rayé). Votre vivier, noté A+. En public. » *(angle vitrine qualité, s'appuie sur VivierQualityCalculator + badge "Agence vérifiée AUTAF")*
- `autaf-06-agences-geo.html` — pattern data-driven, headline « Vos intérimaires. Les chantiers, à 30 km. » *(angle géo-matching local, big-num "30 km" + carte abstraite pins, s'appuie sur zone_intervention ACF agence)*

### Cibles agences d'intérim — règle de positionnement

⚠️ **Une agence d'intérim a déjà ses intérimaires** — elle cherche soit (a) à les **placer** sur des chantiers, soit (b) à **vendre la qualité de son vivier** à ses clients, soit (c) à les **rapprocher des chantiers locaux**. JAMAIS lui vendre « voici plus d'artisans à recevoir » : c'est l'inversion du sens du flux et ça discrédite la pub. Les angles 04/05/06 respectent ce principe.

## Validation utilisateur

> *« Putain c'est parfait, c'est parfait pour AUTAF, c'est incroyable. Là tu as vraiment compris le principe, ça fait start up et tout c'est magnifique. »* — Philippe, 08/05/2026

> *« On doit devenir une licorne. L'objectif c'est la licorne. Tu dois comprendre le principe. »* — Philippe, 09/05/2026 (standard licorne attendu sur tout design AUTAF)

> *« C'est ça que je veux moi c'est des trucs comme ça là t'as raison c'est très bien, c'est original j'adore niveau marketing c'est top franchement »* — Philippe, 09/05/2026 (validation forte direction « objet du quotidien BTP »)

## Notes additionnelles

- AUTAF est en cours de redéveloppement sur un autre VPS (info Philippe 08/05) — donc charte stable, pas de copy nouveau à générer côté plateforme avant info.
- Les vidéos AUTAF (déjà en prod sur `/opt/stack/autaf-videos/`) utilisent la voix Brian ElevenLabs et un phone mockup obligatoire — cohérent avec le ton premium B2B.
