# Pattern · editorial-premium

**Type** : pattern esthétique
**Validé** : 2026-05-08 sur AUTAF professionnels
**Quand l'utiliser** : B2B premium, ton sobre éditorial type Bloomberg/FT, audience qui valorise la sophistication

---

## Caractéristiques

- **Fond foncé profond** (#0F0A35 ou #241B5D AUTAF) avec gradient radial subtil pour la profondeur
- **Grid overlay** discrète (90px AUTAF, opacity 0.04-0.05) façon plan technique / éditorial
- **Eyebrow numérotée** ou **badge-line** en mono ou Inter avec dot/dash décoratif (style « N° 01 — RECRUTEMENT BTP »)
- **Headline 88-118px** weight 800, mix de :
  - Texte en blanc/sombre (corps)
  - **Mot-clef accent en couleur signature** (jaune AUTAF #FFE72B)
  - **Mot rayé** (line-through couleur accent, thickness 6px) sur l'argument repoussoir
- **Lede** 22-28px weight 400, line-height 1.42-1.45, max-width 800px
- **Divider** ligne horizontale gradient subtle au milieu
- **Stats row** ou **features card** entre 2 sections
- **CTA flat rectangulaire** (border-radius 4px, pas de pill) avec ombre portée colorée

## Cibles habituelles

- AUTAF PME / professionnels du BTP (vouvoiement)
- B2B sénior, comité de direction, presse pro

## Variantes selon ton

- **Sombre éditorial agressif** (AUTAF pros) : fond bleu marine #0F0A35 ou #241B5D, accent jaune flashant, grid grise

## Code template canonique

- `templates/ig-portrait-1080-1350/autaf-02-professionnels.html` (sombre éditorial)

## Pièges spécifiques

- **Line-through** : `text-decoration-thickness: 6px` minimum sinon invisible.
- **Italic** : utiliser **Inter Display Italic 700** ou **Medium Italic** (déjà bundled), pas de fallback browser.
- **Grid overlay** opacity > 0.06 = trop visible, casse l'effet premium.
- **Quote-mark décoratif** taille 160-180px line-height 0.6, doit déborder visuellement.
- **Background mark géant** (lettrage AUTAF…) : opacity 0.05-0.08, font-size 350-400px, position absolute négatif right/left pour effet d'ancrage.
