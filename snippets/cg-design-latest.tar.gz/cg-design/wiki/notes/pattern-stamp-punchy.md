# Pattern · stamp-punchy

**Type** : pattern esthétique
**Validé** : 2026-05-08 sur AUTAF artisans
**Quand l'utiliser** : pub scroll-stopper, audience large, ton direct

---

## Caractéristiques

- **Fond couleur signature dominant** (jaune AUTAF #FFE72B)
- **Headline énorme uppercase** 96-124px, weight 900, line-height 0.88-0.92
- **Mot-clef « stamped »** : background couleur secondaire, padding, rotated -2°, box-shadow décalée façon estampillage
- **Bandeau diagonal** en bas en couleur secondaire (clip-path polygon avec offset 90-110px)
- **Stats row** 3 colonnes (chiffres impactants en couleur signature, labels uppercase opacity 0.75)
- **CTA pill** rond grande taille (24-26px font, padding 22-26px × 44-48px), avec fleche en cercle interne
- **Signature/domain** discrète à droite du CTA

## Cibles habituelles

- AUTAF artisans (T'AS UN MARTEAU. ON A 3 CHANTIERS.)
- Personal brand BTP punchy
- Tout cas où le réflexe est : « scroll-stop attention »

## Variantes selon ton

- **Tutoiement direct** (artisans) : verbe d'action, abréviations OK, exclamations

## Code template canonique

Voir `templates/ig-portrait-1080-1350/autaf-01-artisans.html` (référence stamp-punchy AUTAF jaune dominant).

## Pièges spécifiques

- Le **stamp rotated** doit avoir une box-shadow assez forte pour ressortir : `box-shadow: 8px 8px 0 rgba(0,0,0,0.12)` minimum.
- La **punchline sous le H1** doit tenir en 2 lignes max, sinon elle se fait couper par le bandeau diagonal.
- Le **bandeau diagonal** doit laisser ≥80px de hauteur clear avant le contenu sur fond foncé pour pas masquer le texte.
- Le **CTA pill** doit avoir un padding horizontal généreux (>40px) pour bien ressortir.
