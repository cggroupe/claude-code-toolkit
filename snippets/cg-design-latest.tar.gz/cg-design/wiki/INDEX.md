# cg-design — Wiki Karpathy

> **Pattern Karpathy LLM-wiki** — 3 couches : `schema.md` (ground truth taxonomie) + `notes/*.md` (notes atomiques) + `README.md` (vue compilée à la racine du projet).
> Chaque note = un concept queryable. Cross-linké. Compile once, query forever.

---

## 🗂️ Structure

```
/opt/stack/cg-design/
├── README.md          ← guide d'utilisation rapide
├── CLAUDE.md          ← instructions Claude (comment générer un design)
├── wiki/
│   ├── INDEX.md       ← (ce fichier) navigation
│   ├── schema.md      ← taxonomie marque · formats · patterns · couleurs
│   └── notes/
│       ├── stack-foundations.md
│       ├── pattern-stamp-punchy.md
│       ├── pattern-editorial-premium.md
│       ├── pattern-data-driven.md
│       └── brand-autaf.md
└── log.md             ← journal des opérations (chronologique)
```

---

## 🚨 Notes — fondations stack

| Note | Scope |
|---|---|
| [stack-foundations](notes/stack-foundations.md) | Stack technique (HTML/CSS + Puppeteer + General Sans) |

---

## 🎨 Notes — patterns esthétiques

3 patterns validés sur AUTAF :

| Note | Quand l'utiliser |
|---|---|
| [pattern-stamp-punchy](notes/pattern-stamp-punchy.md) | Pub directe scroll-stopper, audience large (artisans) |
| [pattern-editorial-premium](notes/pattern-editorial-premium.md) | B2B premium, ton sobre éditorial (PME, pros) |
| [pattern-data-driven](notes/pattern-data-driven.md) | Partenaires, institutionnels, big number factuel |

Pour les **20 carrousels DTU** (templates 76-155), voir le pattern blueprint navy / yellow inversé documenté dans `log.md` (entrée 21/05).

---

## 🏢 Notes — marque

| Note | Couleurs signature | Statut |
|---|---|---|
| [brand-autaf](notes/brand-autaf.md) | `#241B5D` + `#FFE72B` | ✅ design pur AUTAF (charte stricte) |

---

## ➡️ Voir aussi

- `schema.md` — taxonomie complète (formats supportés, conventions naming, champs `brand.json`)
- `log.md` (racine projet) — journal des opérations chronologique
- `README.md` (racine projet) — guide d'utilisation rapide CLI + API
