#!/usr/bin/env node
/**
 * cg-design batch renderer
 *
 * Usage :
 *   node src/render.js                                    → tous les templates × tous les formats codés
 *   node src/render.js --brand brh                        → uniquement BRH
 *   node src/render.js --template autaf-21                → un template (substring match)
 *   node src/render.js --variant electricien              → tous les variants nommés "electricien"
 *   node src/render.js --template autaf-21-receipt --variant electricien
 *                                                          → un template × un variant précis
 *   node src/render.js --format ig-square-1080            → uniquement format square
 *
 * Variants : voir src/variants.js (tokens {{TOKEN}} dans HTML, JSON dans variants/<tpl>/<name>.json)
 */

const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');
const { loadVariant, listAllVariants, applyTokens, outputName } = require('./variants');

const ROOT = path.resolve(__dirname, '..');
const TEMPLATES_DIR = path.join(ROOT, 'templates');
const OUTPUT_DIR = path.join(ROOT, 'output');

const args = process.argv.slice(2);
function arg(name) {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : null;
}
const brandFilter = arg('--brand');
const templateFilter = arg('--template');
const variantFilter = arg('--variant');
const formatFilter = arg('--format');
const noVariants = args.includes('--no-variants');
const variantsOnly = args.includes('--variants-only');

const FORMATS = {
  'ig-portrait-1080-1350': { width: 1080, height: 1350 },
  'ig-square-1080': { width: 1080, height: 1080 },
  'ig-story-1080-1920': { width: 1080, height: 1920 },
  'linkedin-landscape-1200-627': { width: 1200, height: 627 },
  'tiktok-cover-1080-1920': { width: 1080, height: 1920 },
};

function discoverTemplateFiles() {
  const out = [];
  for (const formatDir of fs.readdirSync(TEMPLATES_DIR)) {
    if (!FORMATS[formatDir]) continue;
    if (formatFilter && formatDir !== formatFilter) continue;
    const fmt = FORMATS[formatDir];
    const dir = path.join(TEMPLATES_DIR, formatDir);
    for (const file of fs.readdirSync(dir)) {
      if (!file.endsWith('.html')) continue;
      const name = file.replace('.html', '');
      const brand = name.split('-')[0];
      if (brandFilter && brand !== brandFilter) continue;
      if (templateFilter && !name.includes(templateFilter)) continue;
      out.push({
        name, brand, format: formatDir,
        width: fmt.width, height: fmt.height,
        htmlPath: path.join(dir, file),
      });
    }
  }
  return out;
}

function buildTasks() {
  const templateFiles = discoverTemplateFiles();
  const tasks = [];

  for (const tf of templateFiles) {
    // 1. Render base (sans variant) sauf si --variants-only
    if (!variantsOnly) {
      tasks.push({ ...tf, variant: null });
    }

    // 2. Render variants (si --no-variants n'est pas passé)
    if (noVariants) continue;

    const variantsDir = path.join(ROOT, 'variants', tf.name);
    if (!fs.existsSync(variantsDir)) continue;

    for (const vf of fs.readdirSync(variantsDir)) {
      if (!vf.endsWith('.json')) continue;
      const variantName = vf.replace('.json', '');
      if (variantFilter && variantName !== variantFilter && !variantName.includes(variantFilter)) continue;
      tasks.push({ ...tf, variant: variantName });
    }
  }

  // Si --variant spécifié sans --template, on a peut-être ajouté des variants — on filtre les bases
  if (variantFilter) {
    return tasks.filter(t => t.variant === variantFilter || (t.variant && t.variant.includes(variantFilter)));
  }
  return tasks;
}

(async () => {
  if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  const tasks = buildTasks();
  if (tasks.length === 0) {
    console.error('Aucun template/variant trouvé.');
    process.exit(1);
  }

  console.log(`→ ${tasks.length} render(s) à effectuer`);

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--font-render-hinting=none'],
  });

  for (const t of tasks) {
    const outFile = outputName(t.name, t.variant, t.format);
    const outPath = path.join(OUTPUT_DIR, outFile);

    let html = fs.readFileSync(t.htmlPath, 'utf8');
    const tokens = t.variant ? (loadVariant(t.name, t.variant).tokens || {}) : {};
    // Toujours appliquer applyTokens : sans variant, les fallbacks {{TOKEN|défaut}} sont utilisés
    html = applyTokens(html, tokens);

    const page = await browser.newPage();
    await page.setViewport({ width: t.width, height: t.height, deviceScaleFactor: 2 });
    await page.setContent(html, { waitUntil: 'networkidle0' });
    await new Promise(r => setTimeout(r, 400));
    await page.screenshot({
      path: outPath, type: 'png', omitBackground: false,
      clip: { x: 0, y: 0, width: t.width, height: t.height },
    });
    const stat = fs.statSync(outPath);
    const tag = t.variant ? ` [variant: ${t.variant}]` : '';
    console.log(`  ✓ ${outFile}  (${(stat.size/1024).toFixed(0)} KB)${tag}`);
    await page.close();
  }

  await browser.close();
  console.log(`\n✓ Rendus dans ${OUTPUT_DIR}/`);
})().catch(e => { console.error(e); process.exit(1); });
