/**
 * cg-design · système de variants
 *
 * Un variant = un set de tokens à injecter dans un template HTML.
 * Tokens dans le HTML : {{TOKEN_NAME}} (remplacés au render).
 *
 * Structure :
 *   variants/<template-base-name>/<variant-name>.json
 *
 * Format JSON :
 *   {
 *     "name": "autaf-21-receipt-electricien",
 *     "template": "autaf-21-receipt",
 *     "tokens": {
 *       "PRO_NAME": "Julien L.",
 *       "PRO_METIER": "Électricien · habilité",
 *       ...
 *     }
 *   }
 *
 * Sans variant : le template est rendu tel quel (les {{tokens}} restent visibles
 * sauf si le template a des valeurs par défaut hard-codées).
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const VARIANTS_DIR = path.join(ROOT, 'variants');

function loadVariant(templateName, variantName) {
  const p = path.join(VARIANTS_DIR, templateName, `${variantName}.json`);
  if (!fs.existsSync(p)) {
    throw new Error(`Variant introuvable: ${p}`);
  }
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function listVariants(templateName) {
  const dir = path.join(VARIANTS_DIR, templateName);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .map(f => f.replace('.json', ''));
}

function listAllVariants() {
  if (!fs.existsSync(VARIANTS_DIR)) return [];
  const out = [];
  for (const tpl of fs.readdirSync(VARIANTS_DIR)) {
    const dir = path.join(VARIANTS_DIR, tpl);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith('.json')) continue;
      out.push({ template: tpl, variant: f.replace('.json', '') });
    }
  }
  return out;
}

/**
 * Applique les tokens dans un HTML.
 * Syntaxes supportées :
 *   {{TOKEN}}                      → valeur HTML-escapée, sinon vide
 *   {{!TOKEN}}                     → valeur brute (HTML autorisé, ex: <em>…</em>)
 *   {{TOKEN|valeur par défaut}}    → valeur si présente, sinon "valeur par défaut" (escapée)
 *   {{!TOKEN|<em>fallback</em>}}   → valeur brute si présente, sinon fallback brut
 */
function applyTokens(html, tokens) {
  return html.replace(/\{\{(!?)([A-Z0-9_]+)(?:\|([^}]*))?\}\}/g, (match, raw, key, fallback) => {
    let val;
    if (key in tokens && tokens[key] !== undefined && tokens[key] !== null) {
      val = String(tokens[key]);
    } else if (fallback !== undefined) {
      val = fallback;
    } else {
      return ''; // token non trouvé, pas de fallback : on enlève
    }
    return raw === '!' ? val : escapeHtml(val);
  });
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Construit le nom d'output à partir d'un variant.
 * Sans variant : <template>__<format>.png
 * Avec variant : <template>--<variant>__<format>.png
 */
function outputName(templateName, variantName, format) {
  const base = variantName ? `${templateName}--${variantName}` : templateName;
  return `${base}__${format}.png`;
}

module.exports = {
  loadVariant,
  listVariants,
  listAllVariants,
  applyTokens,
  outputName,
};
