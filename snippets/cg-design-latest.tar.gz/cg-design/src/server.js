#!/usr/bin/env node
/**
 * cg-design HTTP server (port 8940)
 *
 * Routes:
 *   GET /                         → dashboard avec tous les designs générés (par marque)
 *   GET /output/<file>            → PNG statique
 *   GET /brands/<brand>/<asset>   → asset marque (logo, etc.)
 *   GET /api/brands               → JSON list of brands
 *   GET /healthz                  → health check
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const ROOT = path.resolve(__dirname, '..');
const OUTPUT_DIR = path.join(ROOT, 'output');
const BRANDS_DIR = path.join(ROOT, 'brands');
const TEMPLATES_DIR = path.join(ROOT, 'templates');
const PORT = process.env.PORT || 8940;
const HOST = process.env.HOST || '0.0.0.0';

const MIME = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.css': 'text/css', '.js': 'text/javascript',
};

function loadBrands() {
  const brands = {};
  for (const brand of fs.readdirSync(BRANDS_DIR)) {
    if (brand.startsWith('_')) continue;
    const p = path.join(BRANDS_DIR, brand, 'brand.json');
    if (fs.existsSync(p)) brands[brand] = JSON.parse(fs.readFileSync(p, 'utf8'));
  }
  return brands;
}

function listOutputs() {
  if (!fs.existsSync(OUTPUT_DIR)) return [];
  return fs.readdirSync(OUTPUT_DIR)
    .filter(f => f.endsWith('.png'))
    .sort()
    .map(f => {
      const [namePart, formatPart] = f.replace('.png', '').split('__');
      const brand = namePart.split('-')[0];
      const stat = fs.statSync(path.join(OUTPUT_DIR, f));
      return { file: f, name: namePart, brand, format: formatPart || 'unknown', sizeKB: Math.round(stat.size/1024) };
    });
}

function dashboardHTML() {
  const brands = loadBrands();
  const outputs = listOutputs();
  const byBrand = {};
  for (const o of outputs) (byBrand[o.brand] ||= []).push(o);

  const brandSections = Object.keys(byBrand).sort().map(b => {
    const brandData = brands[b] || { name: b.toUpperCase(), colors: { primary: '#71717A', accent: '#FAFAFA' } };
    const items = byBrand[b].map(o => `
      <div class="card">
        <div class="imgwrap"><img src="/output/${o.file}" alt="${o.name}"></div>
        <div class="body">
          <div class="meta">
            <span class="dot" style="background:${brandData.colors.accent || brandData.colors.primary}"></span>
            <span>${o.format}</span>
            <span class="size">${o.sizeKB} KB</span>
          </div>
          <div class="name">${o.name}</div>
          <a href="/output/${o.file}" target="_blank">Plein écran ↗</a>
        </div>
      </div>
    `).join('');
    return `
      <section class="brand-section">
        <div class="brand-head" style="--accent:${brandData.colors.accent || brandData.colors.primary};--primary:${brandData.colors.primary}">
          <h2>${brandData.name}</h2>
          <span class="brand-tagline">${brandData.tagline || ''}</span>
        </div>
        <div class="grid">${items}</div>
      </section>
    `;
  }).join('');

  return `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>cg-design · Dashboard</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:-apple-system,"Inter Display","Segoe UI",sans-serif;background:#0A0A0A;color:#FAFAFA;-webkit-font-smoothing:antialiased;padding:60px 40px}
  header{max-width:1280px;margin:0 auto 50px;display:flex;align-items:baseline;justify-content:space-between;border-bottom:1px solid #27272A;padding-bottom:28px}
  header h1{font-size:32px;font-weight:800;letter-spacing:-0.03em}
  header h1 .accent{color:#71717A;font-weight:500}
  header .meta{font-size:13px;color:#71717A;font-weight:500;text-align:right;line-height:1.6}
  header .meta b{color:#FAFAFA;display:block}
  .brand-section{max-width:1280px;margin:0 auto 80px}
  .brand-head{display:flex;align-items:baseline;gap:18px;padding-bottom:18px;margin-bottom:28px;border-bottom:1px solid var(--accent);position:relative}
  .brand-head::before{content:"";position:absolute;left:0;bottom:-1px;width:120px;height:3px;background:var(--accent)}
  .brand-head h2{font-size:28px;font-weight:800;letter-spacing:-0.025em}
  .brand-head .brand-tagline{color:#71717A;font-size:14px;font-style:italic}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:32px}
  .card{background:#18181B;border:1px solid #27272A;border-radius:14px;overflow:hidden;transition:transform .2s,border-color .2s}
  .card:hover{transform:translateY(-3px);border-color:#52525B}
  .imgwrap{background:#0A0A0A;display:flex;align-items:center;justify-content:center;aspect-ratio:1080/1350;overflow:hidden}
  .imgwrap img{width:100%;height:100%;object-fit:contain;display:block}
  .body{padding:20px 24px}
  .meta{display:flex;align-items:center;gap:10px;font-size:11px;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:#71717A;margin-bottom:8px}
  .meta .dot{width:8px;height:8px;border-radius:50%}
  .meta .size{margin-left:auto;color:#52525B}
  .name{font-size:18px;font-weight:700;letter-spacing:-0.015em;margin-bottom:10px;color:#FAFAFA}
  .body a{display:inline-block;color:#A1A1AA;font-size:13px;font-weight:600;text-decoration:none;padding:7px 12px;background:#27272A;border-radius:7px;transition:background .15s,color .15s}
  .body a:hover{background:#FAFAFA;color:#0A0A0A}
  footer{max-width:1280px;margin:60px auto 0;text-align:center;color:#52525B;font-size:13px;padding-top:30px;border-top:1px solid #27272A}
</style>
</head><body>
<header>
  <h1>cg-design <span class="accent">· dashboard</span></h1>
  <div class="meta">
    <b>${outputs.length} design${outputs.length>1?'s':''} · ${Object.keys(byBrand).length} marque${Object.keys(byBrand).length>1?'s':''}</b>
    Stack : Puppeteer + HTML/CSS · port 8940
  </div>
</header>
${brandSections || '<p style="text-align:center;color:#71717A">Aucun design rendu. Lance <code>node src/render.js</code></p>'}
<footer>cg-design · /opt/stack/cg-design · VPS CG GROUPE</footer>
</body></html>`;
}

function serveFile(res, filePath, contentType) {
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=300',
    });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const u = url.parse(req.url);
  const p = decodeURIComponent(u.pathname);

  if (p === '/healthz') { res.writeHead(200, {'Content-Type':'application/json'}); res.end(JSON.stringify({ok:true,service:'cg-design',port:PORT})); return; }
  if (p === '/' || p === '/index.html') { res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'}); res.end(dashboardHTML()); return; }
  if (p === '/api/brands') { res.writeHead(200, {'Content-Type':'application/json'}); res.end(JSON.stringify(loadBrands(), null, 2)); return; }

  if (p.startsWith('/output/')) {
    const file = p.slice('/output/'.length);
    if (file.includes('..')) { res.writeHead(400); res.end(); return; }
    const fp = path.join(OUTPUT_DIR, file);
    serveFile(res, fp, MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream');
    return;
  }
  if (p.startsWith('/export/')) {
    const file = p.slice('/export/'.length);
    if (file.includes('..')) { res.writeHead(400); res.end(); return; }
    const fp = path.join(ROOT, '_export', file);
    if (!fs.existsSync(fp)) { res.writeHead(404); res.end('Export not found. Run: bash scripts/build-export.sh'); return; }
    serveFile(res, fp, 'application/gzip');
    return;
  }
  if (p.startsWith('/brands/')) {
    const sub = p.slice('/brands/'.length);
    if (sub.includes('..')) { res.writeHead(400); res.end(); return; }
    const fp = path.join(BRANDS_DIR, sub);
    serveFile(res, fp, MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream');
    return;
  }

  res.writeHead(404, {'Content-Type':'text/plain'});
  res.end('Not found');
});

server.listen(PORT, HOST, () => {
  console.log(`cg-design server → http://${HOST}:${PORT}/`);
});
