#!/usr/bin/env bash
# cg-design — installer portable
# Usage: bash install.sh [--target /opt/stack/cg-design] [--port 8940] [--no-systemd]
#
# Ce script :
#   1. Installe Puppeteer + Inter Display si manquants
#   2. Vérifie les dépendances système (Node 20+, Python3, fonts)
#   3. Setup le service systemd cg-design-api (sauf --no-systemd)
#   4. Lance un premier render pour valider
#
# Tested on Ubuntu 22.04 / 24.04. Adapter selon distrib.

set -euo pipefail

TARGET="/opt/stack/cg-design"
PORT=8940
WITH_SYSTEMD=1

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --no-systemd) WITH_SYSTEMD=0; shift ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

cd "$TARGET"

echo "=== cg-design installer ==="
echo "Target: $TARGET"
echo "Port:   $PORT"
echo "Systemd: $([ $WITH_SYSTEMD -eq 1 ] && echo yes || echo no)"
echo

# 1. Node.js
if ! command -v node >/dev/null; then
  echo "❌ Node.js manquant. Installe Node 20+ (curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -)"
  exit 1
fi
NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
[ "$NODE_MAJOR" -ge 20 ] || { echo "❌ Node.js >= 20 requis (actuel: $NODE_MAJOR)"; exit 1; }
echo "✓ Node.js $(node --version)"

# 2. Polices Inter
if ! fc-list | grep -q "Inter Display"; then
  echo "→ Installation Inter + Inter Display..."
  TMPF=$(mktemp -d)
  cd "$TMPF"
  curl -sL "https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip" -o inter.zip
  unzip -q inter.zip
  mkdir -p /usr/share/fonts/opentype/inter
  cp -f extras/otf/InterDisplay-*.otf /usr/share/fonts/opentype/inter/ 2>/dev/null || true
  cp -f extras/otf/Inter-*.otf /usr/share/fonts/opentype/inter/ 2>/dev/null || true
  fc-cache -fv >/dev/null
  cd "$TARGET"; rm -rf "$TMPF"
  echo "✓ Inter installé"
else
  echo "✓ Inter Display déjà installé"
fi

# 3. Puppeteer (via npm si pas de node_modules)
if [ ! -d "node_modules/puppeteer" ]; then
  echo "→ Installation Puppeteer..."
  npm install puppeteer@^24.0.0 --no-audit --no-fund --silent
  echo "✓ Puppeteer installé"
else
  echo "✓ Puppeteer déjà présent"
fi

# 4. Dépendances système Chromium (libs minimales)
MISSING_LIBS=$(ldd node_modules/puppeteer/.local-chromium/*/chrome-*/chrome 2>/dev/null | grep "not found" || true)
if [ -n "$MISSING_LIBS" ]; then
  echo "⚠ Libs Chromium manquantes :"
  echo "$MISSING_LIBS"
  echo "→ Installe avec: apt-get install -y libnss3 libatk1.0-0 libatk-bridge2.0-0 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2t64"
fi

# 5. Render initial
echo "→ Render initial..."
mkdir -p output
node src/render.js 2>&1 | grep -E "✓|→" || echo "  (pas de templates trouvés)"

# 6. Systemd
if [ $WITH_SYSTEMD -eq 1 ] && command -v systemctl >/dev/null; then
  echo "→ Setup service systemd cg-design-api..."
  cat > /etc/systemd/system/cg-design-api.service <<EOF
[Unit]
Description=cg-design HTTP server (multi-brand ad generator)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
ExecStart=/usr/bin/node src/server.js
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=$PORT
StandardOutput=append:/var/log/cg-design-api.log
StandardError=append:/var/log/cg-design-api.log

[Install]
WantedBy=multi-user.target
EOF
  touch /var/log/cg-design-api.log
  systemctl daemon-reload
  systemctl enable --now cg-design-api.service
  sleep 2
  if systemctl is-active --quiet cg-design-api.service; then
    echo "✓ Service systemd actif"
  else
    echo "⚠ Service systemd échec (vérifie: journalctl -u cg-design-api -n 50)"
  fi

  # UFW (best-effort)
  if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow $PORT/tcp comment "cg-design-api" >/dev/null
    echo "✓ UFW $PORT/tcp ouvert"
  fi
fi

# 7. Smoke test
echo
echo "=== Smoke test ==="
sleep 1
if curl -sf "http://127.0.0.1:$PORT/healthz" >/dev/null; then
  echo "✓ Server répond sur http://127.0.0.1:$PORT/"
  PUBLIC_IP=$(curl -s ifconfig.me 2>/dev/null || echo "<your-vps-ip>")
  echo "  Dashboard: http://$PUBLIC_IP:$PORT/"
else
  echo "⚠ Server ne répond pas. Lance manuellement: cd $TARGET && node src/server.js"
fi

echo
echo "=== Installation terminée ==="
echo "Dossier: $TARGET"
echo "Port:    $PORT"
echo "Logs:    /var/log/cg-design-api.log (si systemd)"
echo "Doc:     $TARGET/README.md, $TARGET/CLAUDE.md"
