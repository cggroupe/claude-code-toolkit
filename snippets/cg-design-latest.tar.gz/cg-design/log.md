# cg-design — Journal des opérations

> Journal chronologique. Une ligne par opération significative. Format : `## YYYY-MM-DD — titre`.

---

## 2026-05-21 — Batch massif 20 DTU avec audit qualité (templates 76-155)

Livraison de **20 carrousels DTU complets** (80 templates HTML + 80 PNG rendus), 4 slides par DTU, en **alternance NAVY (10) / YELLOW (10)** sur charte AUTAF stricte (#241B5D + #FFE72B + #FFFFFF + #FF6B6B/#DC2626 parcimonieux pour warnings).

**Workflow qualité appliqué** (après une vague 1 d'origine truffée d'erreurs factuelles — confusion DTU/RE2020/CEE/NF EN, BA25 inexistant, DTU 45.10 confondu avec 45.11, Uw attribué au DTU au lieu de RE2020, classements AEV attribués à RE2020 au lieu de NF EN 12207/12208/12210, etc.) :
1. **Gel** des PNG fautifs dans `output/_pending-audit/` (plus servis publiquement)
2. Audit par lots de 4 DTU : **WebSearch + WebFetch** sur sources pro (Batirama, Batiactu, CAPEB, Industries du Plâtre, Knauf, Sivalbp, Aldes, Poujoulat, Cochebat, Saint-Gobain Glass, etc.)
3. Brief tabulaire avec valeurs sourcées soumis au user pour validation explicite par lot
4. Codage par sub-agents parallèles (4 en parallèle par lot) avec **consigne anti-invention stricte** ("si la valeur n'est pas dans le brief, retire-la ou reformule en principe")
5. Render + Read d'échantillons PNG par lot

**Carte des 20 DTU livrés** (style / fichiers / valeurs clés sourcées) :

| # | Norme | Métier | Palette | Fichiers | Valeurs clés |
|---|-------|--------|---------|----------|--------------|
| 1 | DTU 60.11 | Plomberie sanitaire | NAVY | 76-79 | Pentes 1/2 cm/m, Ø lavabo 33 / WC 100 mm |
| 2 | DTU 40.21 | Couverture tuiles | YELLOW | 80-83 | Pente 35-55% selon zone, recouvrement ≥ 75 mm |
| 3 | DTU 25.41 | Plâtrerie BA13 | NAVY | 84-87 | BA13/15/18, entraxe 60 cm, vis 30 cm max métal |
| 4 | DTU 45.11 | Isolation soufflée | YELLOW | 88-91 | 8/10 cm sécurité conduits, 4 piges/100m², chemin 60cm |
| 5 | DTU 26.1 | Enduits façades | NAVY | 92-95 | Gobetis 1-5mm + corps 15-20mm + finition 5-8mm, séchage ≥48h+7j |
| 6 | DTU 36.5 | Menuiseries ext | YELLOW | 96-99 | Appui ≥13mm, mastic ≥13mm avant pose, mousse PU interdite |
| 7 | DTU 31.1 | Charpente bois | NAVY | 100-103 | Pannes 63×175/75×200/100×225, flèche L/300/L/200/L/400 |
| 8 | DTU 20.1 | Maçonnerie blocs | YELLOW | 104-107 | Joints 10±2mm épais / 1-3mm minces, mortier M5 mini |
| 9 | DTU 43.1 | Étanchéité toit terrasse | NAVY | 108-111 | Pente ≤5%, noues ≥0,5%, T° pose >+2°C, bicouche SBS |
| 10 | DTU 59.1 | Peinture intérieure | YELLOW | 112-115 | T° 8-35°C, hygro ≤70%, finitions A/B/C |
| 11 | DTU 65.10 | Chauffage canalisations | NAVY | 116-119 | T° ≤110°C, calorifuge zones non chauffées (Règles Pro 2021) |
| 12 | DTU 41.2 | Bardage bois | YELLOW | 120-123 | Lame d'air ≥20mm, ventil 50 cm²/m, double tasseautage vertical |
| 13 | DTU 52.1 | Carrelage scellé | NAVY | 124-127 | Joints 2-6mm selon élément, fractionnement ≤60m²/8m |
| 14 | DTU 13.3 | Dallage béton | YELLOW | 128-131 | 120/130/150mm selon usage, 0,2% armatures, joints retrait <48h |
| 15 | DTU 24.1 | Conduits de fumée | NAVY | 132-135 | 8/16 cm sécurité, T° paroi ≤50°C habitable, classes T080→T600 |
| 16 | DTU 64.1 | Assainissement NC | YELLOW | 136-139 | Fosse 3 m³ jusqu'à 5 pièces, +1 m³/pièce au-delà |
| 17 | DTU 68.3 | VMC | NAVY | 140-143 | Vitesse 4/5/6 m/s, Ø rejet ≥160mm, fuite ≤12% (5% classe C) |
| 18 | DTU 39 | Vitrerie miroiterie | YELLOW | 144-147 | Familles monolithique/trempé/feuilleté + NF EN 1279/12150/14449 (principes, pas de chiffres précis) |
| 19 | DTU 21 | Béton armé | NAVY | 148-151 | Enrobage ≥2,5cm XC4, E/C <0,50, ciment 350 kg/m³, décoffrage 5/15/20 MPa |
| 20 | DTU 33.1 | Façades rideaux | YELLOW | 152-155 | Inclinaison ≤15°, flèche ±2/±5mm, NF EN 12152-12155, T° -20/+80°C |

**Sources WebFetch utilisées** : Batirama, Batiactu, CAPEB, Les Industries du Plâtre, Pladur, Knauf Insulation, Sivalbp, Novi-Clous, Aldes, Xpair, Batiadvisor, Cible-Energie, Cochebat, Poujoulat, FFBatiment, Obat, Toutsurlebeton, Saint-Gobain Glass, actu-environnement, Tricel, ANC-developpement-durable.gouv.fr, Le Moniteur.

**Pattern d'inversion charte** :
- NAVY : fond `#241B5D` + cadres/cartouche en `#FFE72B` + dessins en blanc + valeurs en jaune. Logo footer `#FFE72B`.
- YELLOW : fond `#FFE72B` + cadres/cartouche en `#241B5D` + dessins en navy + valeurs en navy plein. Logo footer `#241B5D`.

**Structure de chaque carrousel (4 slides)** :
1. Intro + grand schéma technique + bulle "3 règles clés"
2. 2-3 cas (panels grids style autaf-77/81) + valeurs cotées
3. Tableau technique avec colonnes Paramètre / Valeur DTU
4. Récap 3 règles (`data-num` chips + .why détaillée) + CTA "trouve un [métier] AUTAF"

**Polices** : General Sans (12 graisses) + Waiting for the Sunrise (Sunrise — annotations manuscrites).
**Anti-invention** : aucun chiffre asserté sans source. Sur DTU 39 (vitrerie), CSTB payant et chiffres non sourçables → slides "principes uniquement" sans cotes.

**Reproche correctement traité** : « on n'a pas le droit à l'erreur. » → workflow validation user par lot + attribution normative propre (DTU vs Règlementation thermique vs CEE vs NF EN produits). Plus de mélange.

---

## 2026-05-21 — Batch blueprint plombier DTU 60.11 (templates 76-79, nouveau style)

4 carousels « Fiche pro · Plomberie » en **style blueprint architecte** — radicalement différent des DTU 40 / NF C 15-100 (fond clair, tampon stamp jaune Stabilo).

Charte visuelle « blueprint » :
- Fond **bleu marine profond `#0E2A47`** + quadrillage léger (36px, lignes cyan 6 % opacité)
- Cadre extérieur cyan `#7DD3FC` avec petits chevrons en coin (haut-gauche / bas-droite)
- **Cartouche multi-colonnes** style dossier d'exécution en haut gauche : `Norme | Domaine | Document` avec colonne norme en jaune 38px, séparateurs cyan
- Pas de tampon Stabilo incliné ; à la place une cartouche rectangulaire encadrée cyan
- **Step indicator** dans une boîte cyan encadrée (`02 / 04 · PLAN TECHNIQUE`)
- Accent jaune `#FFE72B` réservé aux **valeurs clés uniquement** (cotes, diamètres, % de pente) — pas en surlignage de mots
- Souligné jaune sous le mot accent du H1 (au lieu du fond Stabilo)
- Rouge `#F87171` (rouge plus chaud que le DC2626 utilisé sur fond clair) pour warnings et lignes à éviter
- Handwrite Waiting for the Sunrise en cyan `#7DD3FC` (annotations neutres) ou rouge `#F87171` (warnings)
- Logo AUTAF en **jaune** en pied de page (au lieu de navy sur fond clair)

Slides livrées :
- **76 (intro)** : schéma de principe réseau eaux usées (lavabo / WC / évier → collecteur Ø 100 → fosse), pente ↘ 1 % annotée handwrite cyan, ventilation primaire vers toiture, cote Ø 100 jaune sur la descente.
- **77 (pentes EU/EV)** : 3 cas en panels rangée — Cas A 1 cm/m, Cas B 2 ±0,5 cm/m, Cas C en rouge `> 3 cm/m = bouchons` (à éviter). Mini-schémas SVG avec gouttes d'eau cyan animant la pente. Valeurs jaunes XXL à droite.
- **78 (diamètres minimum)** : vraie table technique (Appareil / Débit / Ø intérieur / Pente), 5 lignes (lavabo 33 mm · douche 40 mm · évier+lave-linge 40 mm · baignoire 40 mm · WC 100 mm), picto SVG par appareil dans case cyan encadrée.
- **79 (récap)** : 3 règles d'or au format identique aux récaps précédents (data-num chip jaune-sur-navy, .why explicatif, .val jaune) mais sur fond blueprint. CTA card **jaune sur fond bleu marine** avec ombre cyan 6/6 (inversion du contraste précédent). « ↶ à imprimer ! » rouge.

Validation 4 PNG via Read : pas de chevauchement, comprehension claire, palette cohérente, ton « dossier d'exécution » bien tenu. Bonne base pour décliner d'autres DTU dans ce style (45 isolation, 25.41 plâtrerie, 36.5 menuiserie ext).

Pour la suite : style blueprint = template pour les normes techniques précises (cotes, diamètres, débits). Style « tampon jaune + handwrite » = template pour les normes plus narratives (qualité, réglementation, sécurité).

---

## 2026-05-21 — Carousels DTU 40.21 + NF C 15-100 v2 (templates 68-75, refonte +50% lisibilité)

Refonte des 8 carousels « fiche pro » DTU/NFC (68-71 couverture · 72-75 élec). Retour Philippe : tampon de norme trop petit, page trop monochrome, on ne comprenait pas vite ce qu'on regardait.

Patron commun appliqué aux 8 slides :
- **Tampon technique géant** (54px, fond jaune Stabilo, bordure 3px navy + ombre dur navy 6/6, rotation -1.2°) à la place de l'ancienne chip 12px. « DTU 40.21 » et « NF C 15-100 » sont désormais les premiers signaux visuels lus.
- **Step indicator XXL** en haut à droite : `02/04` en 38px navy, sous-label `FICHE PRO · TOITURE`, et mention manuscrite `→ swipe` / `● fin` en Waiting for the Sunrise.
- **Kicker manuscrit** rotatif (-1.5°) au-dessus du H1 : `ce que la norme dit vraiment ↓`, `⚠ erreur n°1 sur chantier`, `cotations à la pose ↓`. Fait basculer le ton « publi presse pro » au lieu de doc figé.
- **Sous-titre explicatif enrichi** (avec `<b>` navy/rouge sur les mots-clés) sous le H1 : 19px, ligne 1.4, max-width 760px — donne le « pourquoi on regarde ça » en 2 lignes.
- **Couleur rouge `#DC2626`** introduite pour les cotes critiques, alertes (« erreur n°1 », « crucial ! ») et annotations directionnelles (flèche `sens de l'eau →`). Coexiste sobrement avec le navy/jaune charte. Pas de halo flou.
- **Annotations manuscrites Waiting for the Sunrise** sur les schémas techniques : `↑ sortie d'air`, `entrée d'air ↘`, `5 prises mini !`, `la zone qui sauve`, `↓ une goutte qui glisse`, `tout se mesure depuis le SOL FINI ↓`, `à imprimer !`. Chaque pictogramme a maintenant son explication courte.

Spécificités par slide :
- **68 (coupe maison)** : bulle « 3 règles d'or : ① pente ② recouvrt ③ ventil. » qui donne la table des matières du carousel + flèche rouge pointillée `sens de l'eau` + cercles jaunes accent pour entrées/sortie d'air.
- **69 (3 zones)** : panels colorés différents par exposition (blanc-vert / jaune-pâle / rose-rouge), num bloc carré navy avec chiffre jaune (rouge sur zone 3), icônes thématiques inline (soleil, vagues, pic enneigé), traits de pluie/flocons SVG. Valeurs `35% / 45% / 55%` passées de 48px → 64px.
- **70 (recouvrement)** : cote « ≥ 75 mm » dans un cartouche blanc encadré rouge (et non plus floating au-dessus de la ligne), bulle jaune « la zone qui sauve » avec leader-line, goutte d'eau bleue annotée, flèche `sens de l'eau →` rouge.
- **71 (récap couv)** : `data-num="RÈGLE N"` en chip navy/jaune au-dessus de chaque card + ligne explicative `.why` sous la règle, CTA card avec ombre dure jaune 6/6, annotation manuscrite rouge `↶ à imprimer !`.
- **72 (plan séjour)** : légende encadrée fond `#FFFAE0` avec contour navy à droite (prise / interrupteur / point lumineux / circuit), annotation rouge `5 prises mini !` avec flèche pointillée vers les prises, `plafonnier ↘` et `↓ interrupteur` en manuscrit.
- **73 (4 pièces)** : chip `data-badge` au-dessus de chaque pièce (`PIÈCE PRINCIPALE`, `+ CIRCUITS DÉDIÉS`, `POUR LE LIT`, `SI > 4 M`), pièce séjour en fond crème `#FFFAE0` + chiffre `5` surligné, picto-rooms enrichis (canapé, plan travail labellisé, lit labellisé, point lumineux dans couloir).
- **74 (cotes hauteurs)** : 3 cotes rouges parfaitement séparées + plan de travail en jaune crème, sous-labels `axe à 110 cm`, `≥ 5 cm du sol`, `≥ 8 cm au-dessus`, annotation rouge `tout se mesure depuis le SOL FINI ↓`.
- **75 (récap élec)** : mêmes data-num chips que slide 71, `.why` détaille les cas (3 chambres = 3 prises chacune, cuisine = 6 dont 4 sur plan, etc.), CTA card avec ombre jaune.

Itérations correctives au Read PNG (2) :
- 72 : annotation `5 prises mini !` partiellement masquée par le mur gauche → repositionnée x=80 + flèche pointillée rouge vers le mur haut.
- 70 : cote `≥ 75 mm` visuellement collée à la danger-line → cartouche blanc à contour rouge + remontée à y=173, ligne décalée à y=186.

Tous rendus dans `output/` validés Read PNG. Charte respectée (#FFE72B / #241B5D + DC2626 ajouté pour cotes critiques uniquement). General Sans + Waiting for the Sunrise.

---

## 2026-05-21 — Batch ads marketing/vente AUTAF (templates 34-43)

10 nouveaux templates AUTAF orientés conversion, couvrant Meta / TikTok / LinkedIn / Instagram :

- `autaf-34-shock-question.html` (tiktok-cover-1080-1920) — Question shock fond navy + bloc Stabilo, hook scroll-stopper TikTok/Reels.
- `autaf-35-avant-apres.html` (ig-portrait-1080-1350) — Split 50/50 chaos rouge vs clarté jaune, footer-cards 2 sem. vs 24 h.
- `autaf-36-price-compare.html` (linkedin-landscape-1200-627) — Tableau comparatif AUTAF Pro 29 € vs PJ vs Intérim, ribbon RECOMMANDÉ.
- `autaf-37-counter-live.html` (ig-square-1080) — Compteur live +1 247 inscrits, 3 tickers villes, social proof Meta.
- `autaf-38-testimonial-card.html` (ig-portrait-1080-1350) — Review carte 5★ + 2 mini-quotes + stat-band trois chiffres.
- `autaf-39-newspaper-cover.html` (ig-portrait-1080-1350) — Une de presse "Le Quotidien du BTP", éditorial LinkedIn premium.
- `autaf-40-story-fomo.html` (ig-story-1080-1920) — Countdown 312 places / 6 j / 14 h, scarcity Stories.
- `autaf-41-tampon-urgent.html` (ig-portrait-1080-1350) — Bordereau de chantier kraft + tampon URGENT centré, direction "objet quotidien".
- `autaf-42-big-stat-97.html` (ig-square-1080) — 97 % outline + bloc jaune scotché (signature `.f-chiffres`), annotation handwrite.
- `autaf-43-cta-engagement.html` (linkedin-landscape-1200-627) — Engagement bait "Commente CHANTIER", post-mockup LinkedIn.

Itérations correctives faites après premier render :
- 34 : `box-decoration-break: clone` cassait le "q" de "qui" → remplacé par `display: inline-block` + padding manuel.
- 35 : trop d'espace vide en bas des colonnes → ajout footer-cards chiffrées.
- 37 : pseudo-élément `::before` traversait les chiffres → remplacé par flex inline avec gap propre.
- 38 : espace jaune mort entre carte et stat-band → ajout 2 mini-quotes pour combler.
- 41 : `.doc-cta` flottait en haut (form court) → `display:flex; flex-direction:column` + `.spacer` pousse le CTA au bas. Annotation handwrite virée car chevauchait le tampon. Tampon URGENT centré, agrandi (96 px), domine la zone vide.
- 42 : "%" écrasait le titre droit → repositionnement du `%` collé au "97" + bloc explainer descendu en grid 2 colonnes sous les chiffres.

Tous rendus dans `output/` validés par Read PNG. Pas de gradient flou, formes nettes, charte respectée (#FFE72B / #241B5D), General Sans + Waiting for the Sunrise.

---

## 2026-05-08 — Bootstrap stack v0

- Création arborescence `/opt/stack/cg-design/` (brands, templates, src, output, wiki).
- Migration des 3 templates AUTAF depuis `/root/autaf-design-test/` (artisans, professionnels, agences).
- Création `brands/autaf/brand.json` + `logo.svg` (SVG officiel `LOGO_autaf_bleu.svg` extrait de `autaf.fr`).
- Création `brands/brh/brand.json` + `logo.png` (`brhlogo-removebg-preview.png`) + `logo-pro.png` (`brhPRO.png`) depuis `/opt/stack/documents/entreprises/Bretagne_Renovation_Habitat/Images/`.
- Création `brands/cg-groupe/README.md` placeholder (charte à formaliser plus tard).
- Codage 3 templates BRH IG portrait : `brh-01-particuliers.html`, `brh-02-seniors.html`, `brh-03-partenaires.html` (3 patterns esthétiques différents).
- Codage `src/render.js` (CLI batch render multi-format multi-brand) et `src/server.js` (HTTP dashboard port 8940).
- Service systemd `cg-design-api.service` créé + activé + actif. Healthcheck 200 OK.
- Wiki Karpathy initial (INDEX, schema, 6 notes : foundations + 3 patterns + 2 brands).
- Fix BRH 03 : digits 200px → 156px + `white-space: nowrap` pour éviter overflow du big number sur le footer.

**Validation Philippe sur AUTAF** : *« Putain c'est parfait, c'est parfait pour AUTAF, c'est incroyable. Là tu as vraiment compris le principe, ça fait start up et tout c'est magnifique. »*

**Status final** : 6 templates rendus (3 AUTAF + 3 BRH), service systemd actif, dashboard accessible sur http://147.93.52.70:8940/.

---

## 2026-05-08 — Import stack sur 2nd VPS + 3 templates agences d'intérim

- Tarball téléchargé depuis VPS source `147.93.52.70:8940/export/cg-design-latest.tar.gz` puis `bash install.sh` → service `cg-design-api` actif sur ce VPS-ci, port 8940. 6 templates initiaux re-rendus à l'install.
- Codage 3 nouveaux templates AUTAF ciblant **agences d'intérim BTP**, fondés sur l'audit code AUTAF local (vrais features : marketplace chantiers + matching équipe + score qualité vivier public + zone d'intervention + multi-affiliation cloisonnée) :
  - `autaf-04-agences-placement.html` — pattern stamp-punchy, angle « Vos profils. Nos chantiers. En 1 clic. » (placement intérimaires sur chantiers AUTAF).
  - `autaf-05-agences-qualite.html` — pattern editorial-premium, angle « Plus de déclaratif. Votre vivier, noté A+. En public. » (score VivierQualityCalculator + badge agence vérifiée).
  - `autaf-06-agences-geo.html` — pattern data-driven, angle « Vos intérimaires. Les chantiers, à 30 km. » (géo-matching local, carte abstraite avec pins).
- Itérations détectées au Read PNG : punchline 04 trop longue (3 lignes → coupée par sig+bandeau diagonal) → raccourcie à 2 lignes. Layout 06 : H1 4→3 lignes, lede compactée, big-num digits 220→168px nowrap, caption raccourcie, carte atténuée opacity 0.55. Re-rendus OK.
- **Reçu reproche utilisateur** : 1ère version des 3 angles renversait le sens du flux (vendre des artisans aux agences, alors que les agences placent leurs propres intérimaires). Refonte angles → placement / vitrine qualité / géo-local.

---

## 2026-05-09 — Cap 30 templates AUTAF, charte officielle bundlée, nouvelles directions

- **Charte officielle AUTAF récupérée** depuis `/app/autaf/wp-content/themes/autaf/assets/scss/config/_variables.scss` :
  - Couleurs canoniques : `$c-primary: #FFE72B` (jaune Stabilo, primary), `$c-secondary: #241B5D` (navy), `$c-grey-bg: #F2F2F2`, etc.
  - Fontes : `General Sans` (12 graisses) + `Waiting for the Sunrise` (manuscrit). Bundle dans `brands/autaf/fonts/`.
  - 5 classes signature documentées : `.f-chiffres` (chiffre outline + bloc Stabilo), `.texte-rayure` (gribouille feutre), `.texte-correction` (correction handwrite), `.encercle-handwrite`, `.surligne-primary`.
  - `gribouille.png` (PNG rature feutre) bundlé dans `brands/autaf/assets/`.
  - `brand.json` mis à jour. Note legacy : anciens templates 01-06 utilisent Inter Display (mapping erroné) — gardés mais nouveaux templates suivent General Sans.
- **Cap 30 templates AUTAF atteint** (objectif licorne validé Philippe). Décompte final :
  - 6 anciens (01-06) — artisans, pros, agences ×4
  - 7 directions stylistiques (07-blueprint, 08-maxitypo, 09-bento, 10-maxinum, 11-sticker, 12-brutalist, 14-editorial-mag-Wired)
  - 2 atypiques (13-risograph, 15-overlay-photo en charte navy)
  - 1 minimal (19-linear-minimal)
  - 3 partenaires (17-sofinco-announce, 18-sofinco-stat, 23-pointp)
  - 11 « objet du quotidien BTP » : 21-receipt, 24-pointage, 25-permis-construire, 26-tampon-valide, 27-bon-commande, 28-carte-btp, 29-devis-papier, 30-etiquette-palette, 31-carte-visite, 32-affichette-palissade, 33-launch-equipes
- Templates rejetés et supprimés : autaf-16-y2k (trop éloigné charte), autaf-20-ticker (trop foncé/illisible), autaf-22-partenaire-qualibat (moyen).
- **Direction « objet du quotidien BTP » très validée** par Philippe (« je suis choqué », « c'est ça que je veux »). À décliner en priorité pour futurs templates.
- **Règles renforcées en mémoire** : pas de halos flous (gradient AI), formes géométriques franches, standard licorne (Stripe/Linear/Vercel), professionnalisme avant tout (pas de bricolage : repenser plutôt que retirer un paramètre).
- **Roadmap suite** : déclinaison multi-formats (square, story 9:16, LinkedIn paysage), branchement futur sur feature UGC chantier (artisan upload photo → génération visuel co-brandé via cg-design).
