# cg-design

**Générateur d'ads multi-marques pour CG GROUPE** (Bretagne Rénovation Habitat, AUTAF, QualiControl, ProElec, WorkRepublic, CG GROUPE corp, Personal brand Philippe).

Stack maison **HTML/CSS + Puppeteer + Inter Display** sur le VPS, **0 €/mois**, contrôle 100% du design.

---

## 🚀 Quick start

### Render tous les designs

```bash
cd /opt/stack/cg-design
node src/render.js                    # tous les templates
node src/render.js --brand brh        # uniquement BRH
node src/render.js --template brh-01  # un template précis
```

### Voir le dashboard

Service systemd `cg-design-api` actif sur port 8940 :

→ **http://147.93.52.70:8940/**

```bash
systemctl status cg-design-api
journalctl -u cg-design-api -f       # logs live
sudo tail -f /var/log/cg-design-api.log
```

### Ajouter un nouveau design

1. Choisir un pattern dans [wiki/](wiki/) (stamp-punchy / editorial-premium / data-driven)
2. Copier le template HTML d'une marque/persona similaire
3. Adapter copy, couleurs (depuis `brands/<id>/brand.json`), logo
4. `node src/render.js --template <nom>`
5. Vérifier sur le dashboard

Voir [CLAUDE.md](CLAUDE.md) pour les instructions Claude détaillées.

---

## 🏢 Marques actuelles

| ID | Nom | Couleurs signature | Templates |
|---|---|---|---|
| `autaf` | AUTAF | `#241B5D` + `#FFE72B` | 3 (artisans, professionnels, agences) |
| `brh` | Bretagne Rénovation Habitat | `#147814` + `#E5B045` + `#F8F4ED` | 3 (particuliers, seniors, partenaires) |
| `cg-groupe` | CG GROUPE | (mono noir/blanc luxe Linear/Stripe/Apple) | ⏳ dossier réservé |

## 📐 Formats supportés

| Format dir | Dimensions | Usage |
|---|---|---|
| `ig-portrait-1080-1350` ⭐ | 1080×1350 (4:5) | IG Ads + LinkedIn portrait (codé) |
| `ig-square-1080` | 1080×1080 | Posts carrés (à coder) |
| `ig-story-1080-1920` | 1080×1920 (9:16) | Stories + Reels covers (à coder) |
| `linkedin-landscape-1200-627` | 1200×627 | LinkedIn paysage (à coder) |
| `tiktok-cover-1080-1920` | 1080×1920 (9:16) | TikTok covers (à coder) |

## 📚 Documentation

- [CLAUDE.md](CLAUDE.md) — Instructions Claude pour générer un design
- [wiki/INDEX.md](wiki/INDEX.md) — Wiki Karpathy (patterns, marques, fondations)
- [wiki/schema.md](wiki/schema.md) — Taxonomie + conventions naming + champs canoniques
- [log.md](log.md) — Journal des opérations chronologique

## ⚙️ Stack technique

- **Render** : Puppeteer 24.38 (`/opt/stack/autaf-videos/node_modules` via symlink)
- **Polices** : Inter + Inter Display (système, `/usr/share/fonts/opentype/inter/`)
- **Server** : Node.js plain HTTP port 8940 (systemd `cg-design-api.service`)
- **Logs** : `/var/log/cg-design-api.log`

## 🔧 Maintenance

```bash
systemctl restart cg-design-api      # redémarrer le serveur
node src/render.js                   # re-render tous les designs
```
