# Instructions Claude — cg-design

> Ce fichier indique à Claude (toi) comment générer un design quand l'utilisateur en demande un.

---

## Quand activer ce skill

Dès que l'utilisateur demande :
- « Fais-moi un post LinkedIn / Instagram / Facebook pour [marque] »
- « Pub IG ads pour [cible] »
- « Visuel publicitaire »
- « Carrousel », « Story », « TikTok cover »
- Toute génération graphique liée à AUTAF, BRH, CG GROUPE, QualiControl, ProElec, WorkRepublic, Personal brand Philippe

## Workflow obligatoire

1. **Identifier la marque cible**
   - Si pas explicite, demander à Philippe.
   - Vérifier que `brands/<id>/brand.json` existe. Sinon, créer la charte (couleurs, fonts, tone) avant de continuer.

2. **Choisir le pattern esthétique** parmi les 3 validés :
   - `stamp-punchy` — direct scroll-stopper (artisans, particuliers)
   - `editorial-premium` — B2B sobre éditorial (PME, pros, seniors)
   - `data-driven` — institutionnel chiffré (partenaires, notaires, agences)
   - Voir [wiki/INDEX.md](wiki/INDEX.md) pour le détail.

3. **Choisir le format**
   - Par défaut : `ig-portrait-1080-1350` (Instagram Ads + LinkedIn portrait, le format qui performe le mieux sur les feeds).
   - Autres : `ig-square-1080`, `ig-story-1080-1920`, `linkedin-landscape-1200-627`, `tiktok-cover-1080-1920` (à coder si besoin).

4. **Copier un template existant**
   - Référence : `templates/ig-portrait-1080-1350/<brand>-XX-<persona>.html`
   - Adapter copy, couleurs (depuis `brand.json`), logo, stats.
   - Naming : `<brand>-<index>-<persona>.html` (ex. `brh-04-investisseurs.html`).

5. **Render**
   ```bash
   cd /opt/stack/cg-design
   node src/render.js --template <nouveau-nom>
   ```

6. **Vérifier visuellement** : Read le PNG dans `output/<...>__<format>.png`. Détecter overflow, debordements, polices fallback.

7. **Itérer si besoin** (Edit le template, re-render).

8. **Servir à Philippe** : le service `cg-design-api` tourne déjà sur port 8940. URL dashboard : `http://147.93.52.70:8940/`.

## Ce qu'il NE faut JAMAIS faire

- ❌ Inventer une charte graphique sans vérifier `brand.json` ou les assets dans `brands/<id>/`.
- ❌ Mélanger les directions esthétiques entre marques (BRH = chaleureux local, AUTAF = startup tech, CG GROUPE = luxe mono noir/blanc).
- ❌ Utiliser des polices Google Fonts en URL (Puppeteer = pas de réseau par défaut). Toujours `@font-face file:///`.
- ❌ Oublier le `deviceScaleFactor: 2` (sinon qualité dégueu).
- ❌ Mettre une tagline en rotation -90deg (déjà essayé, ça chevauche le texte — voir log).
- ❌ Big number > 200px sans `white-space: nowrap` (déborde).

## Ce qu'il FAUT faire

- ✅ Toujours mettre à jour `wiki/notes/brand-<id>.md` quand on ajoute un template.
- ✅ Toujours ajouter une ligne à `log.md` (date + ce qui a été fait).
- ✅ Toujours laisser ≥80px de marge avec un bandeau diagonal `clip-path`.
- ✅ Toujours tester en Read le PNG avant de présenter à Philippe.
- ✅ Garder le ton et le copy adaptés à l'ICP (cf. `brand.json` champ `tone` et `icpExamples`).

## Pour ajouter une nouvelle marque

1. `mkdir brands/<id>/`
2. Y coller le logo (SVG préféré, sinon PNG removebg)
3. Créer `brand.json` (cf. schema dans [wiki/schema.md](wiki/schema.md))
4. Créer `wiki/notes/brand-<id>.md`
5. Coder 3 templates initiaux (un par pattern : stamp-punchy + editorial-premium + data-driven)
6. Render + dashboard

## Pour différencier la typographie entre marques

Inter Display est la base par défaut, mais **chaque marque peut avoir sa propre famille** :

1. Télécharger les `.ttf` ou `.woff2` de la police voulue (Google Fonts, Fontshare, MyFonts…) :
   ```bash
   mkdir -p brands/<id>/fonts/
   # ex. Public Sans pour CG GROUPE
   curl -L "https://github.com/googlefonts/public-sans/raw/main/fonts/ttf/PublicSans-Bold.ttf" -o brands/cg-groupe/fonts/PublicSans-Bold.ttf
   ```

2. Dans le template HTML, déclarer la police custom **en plus** de Inter Display :
   ```html
   <style>
     @font-face { font-family: 'Public Sans'; src: url('file:///opt/stack/cg-design/brands/cg-groupe/fonts/PublicSans-Bold.ttf'); font-weight: 700; }
     body { font-family: 'Public Sans', 'Inter Display', sans-serif; }
   </style>
   ```

3. **Conseil de direction artistique** :
   - **Inter Display** (système) — geometric tech, par défaut, parfait pour AUTAF / SaaS
   - **Public Sans** — humanist sans (US Web Design System), parfait pour CG GROUPE corp / institutionnel
   - **Space Grotesk** — geometric retro, pour Personal brand / startup
   - **Outfit** — geometric round, pour BRH chaleureux ou marques B2C
   - **Fraunces** ou **Playfair Display** — serif éditorial, pour éditorial premium
   - **Geist** (Vercel) — neutre tech, pour QualiControl SaaS

   La règle : 1 famille display **distinctive** par marque, et garder Inter pour le texte courant si la display est très typée. Sinon Inter partout = sécurité (mais marques moins reconnaissables au premier coup d'œil).

## Pour ajouter un nouveau format

1. `mkdir templates/<format-id>/` (ex. `ig-square-1080/`)
2. Ajouter l'entrée dans `src/render.js` objet `FORMATS` (déjà fait pour 5 formats)
3. Coder un template canonique en adaptant la mise en page au ratio
4. Render + valider

---

**Dernière validation Philippe** : 08/05/2026 — *« Putain c'est parfait, c'est parfait pour AUTAF, c'est incroyable. Là tu as vraiment compris le principe, ça fait start up et tout c'est magnifique. »*
