# Bienvenue — Stack cg-design AUTAF · Onboarding Claude Code

> **À lire en premier par tout Claude Code qui débarque sur ce stack.**
> Tu es l'agent qui va générer des designs marketing AUTAF. Charte stricte, anti-invention factuelle, qualité licorne.

---

## 🚀 1. Téléchargement express

Sur ton VPS, en root :

```bash
mkdir -p /opt/stack && cd /opt/stack
curl -L http://72.62.178.237:8940/export/cg-design-latest.tar.gz -o cg-design.tar.gz
tar xzf cg-design.tar.gz && rm cg-design.tar.gz
cd /opt/stack/cg-design
bash install.sh
```

Ça va :
- Vérifier Node.js 20+
- Installer Puppeteer + libs Chromium
- Installer les polices (General Sans + Waiting for the Sunrise) embarquées dans le tarball
- Setup le service systemd `cg-design-api` (port 8940)
- Faire un premier render de validation

Dashboard accessible sur `http://<ton-ip>:8940/`.

---

## 🎨 2. La charte AUTAF — non négociable

| Couleur | Hex | Usage |
|---------|-----|-------|
| Navy | `#241B5D` | Fond foncé / texte / cadres |
| Jaune Stabilo | `#FFE72B` | Accent primaire / surlignage / valeurs clés |
| Blanc | `#FFFFFF` | Texte sur navy / traits techniques sur navy |
| Crème | `#FAFAF7` | Fond crème alternatif |
| Rouge | `#DC2626` / `#FF6B6B` | **UNIQUEMENT** pour warnings / cotes critiques (parcimonie) |

**Polices** :
- **General Sans** (12 graisses, dans `brands/autaf/fonts/general-sans/`) — typo principale, titres, body
- **Waiting for the Sunrise** (dans `brands/autaf/fonts/waiting-for-the-sunrise/`) — annotations manuscrites uniquement (`font-family: 'Sunrise'`)

**Interdictions absolues** :
- ❌ Pas de gradient flou / halo (Philippe associe ça à du contenu IA)
- ❌ Pas d'emoji dans les designs
- ❌ Pas de couleur hors charte (notamment pas de cyan / bleu clair / vert)
- ❌ Pas de fonts Google (latence Puppeteer + dépendance réseau)

---

## 🏗️ 3. Les 2 styles "blueprint" validés

Pour les carrousels DTU (fiches techniques BTP), on alterne 2 styles **strictement inversés** :

### Style NAVY (fond foncé)
- Fond `#241B5D` + quadrillage 36px léger blanc 6%
- Cadres / cartouche / step / frame : **jaune `#FFE72B`**
- Dessins techniques / pipes / schémas : **blanc `#FFFFFF`**
- Valeurs clés / cotes / annotations : **jaune**
- Logo footer fill : **jaune**
- Référence : `templates/ig-portrait-1080-1350/autaf-76-blueprint-plombier-{1..4}.html`

### Style YELLOW (fond clair) — **inversion mécanique**
- Fond `#FFE72B` + quadrillage 36px léger navy 6%
- Cadres / cartouche / step / frame : **navy `#241B5D`**
- Dessins techniques : **navy**
- Valeurs clés / cotes : **navy**
- Logo footer fill : **navy**
- Référence : `templates/ig-portrait-1080-1350/autaf-80-yellow-couverture-{1..4}.html`

**Règle d'attribution couleur** : chaque DTU se voit attribuer un style. L'alternance bleu/jaune est faite à chaque DTU pour la cohérence visuelle d'un batch.

---

## 📐 4. Structure type d'un carrousel (4 slides)

| Slide | Contenu |
|-------|---------|
| **1 · Intro** | Cartouche (Norme / Section / Document) + step `01/04` + H1 punchline + sub explicatif + GRAND schéma technique central + bulle "3 règles clés" |
| **2 · Cas** | 2-3 panels (style autaf-77/81) avec mini-schéma + valeur cotée par cas |
| **3 · Tableau** | Table technique avec colonnes Paramètre / Valeur DTU (jaune/navy selon style) |
| **4 · Récap** | 3 règles (`data-num="RÈGLE N"` chips + picto + `.h` + `.why` + `.val`) + CTA card "Trouve un {métier} AUTAF" |

Chaque slide a en haut un **tampon « DTU XX.X »** énorme (style jaune sur fond navy ou navy sur fond jaune), pas une mini-chip. C'est le signal de marque dominant.

---

## 🛡️ 5. Anti-invention — règle d'or factuelle

**On n'a pas le droit à l'erreur sur les chiffres BTP.**

Quand on code un carrousel pour un nouveau DTU :

1. **WebSearch + WebFetch** sur sources pro (Batirama, Batiactu, CAPEB, Industries du Plâtre, Knauf, Aldes, Saint-Gobain, etc.)
2. Construire un **brief tabulaire des valeurs sourcées** (chiffres + provenance)
3. **Faire valider** le brief par Philippe avant codage
4. Coder en **mode anti-invention** : si une valeur n'est pas dans le brief, on la retire ou on reformule en principe
5. Render + Read PNG pour vérifier l'absence de chevauchements

**Glissements normatifs à éviter** :
- ⚠️ Ne pas mélanger DTU (mise en œuvre) avec RE2020 (perf énergétique), CEE/MaPrimeRénov (R minimum aides), ou NF EN (normes produits)
- ⚠️ Bien attribuer : Uw → RE2020 ; AEV → NF EN 12207/12208/12210 ; R isolation minimum → CEE (pas DTU 45)
- ⚠️ DTU 45.10 = panneaux/rouleaux ≠ DTU 45.11 = laine soufflée
- ⚠️ Une plaque BA25 n'existe pas (BF15/BF18 pour coupe-feu)

---

## 🛠️ 6. Comment générer un nouveau design — workflow détaillé

### Cas A : nouveau carrousel DTU

```bash
# 1. Audit
# Faire WebSearch sur "DTU XX.X [métier] valeurs clés"
# Faire WebFetch sur 1-2 sources officielles (Batirama, CAPEB…)
# Construire brief tabulaire

# 2. Coder en s'inspirant strictement d'un modèle existant
# - Pour NAVY : copier autaf-76 à 79
# - Pour YELLOW : copier autaf-80 à 83
# Conserver le CSS INTÉGRALEMENT. Modifier UNIQUEMENT :
#   - cartouche (Norme / Section / Document)
#   - step lbl
#   - H1 + kicker + sub
#   - bloc SVG technique (schéma adapté au DTU)
#   - tech-foot
#   - bottom src

# 3. Render
cd /opt/stack/cg-design
node src/render.js --brand autaf --template <nom-template>

# 4. Validation visuelle (toujours)
# Read le PNG produit. Vérifier :
#   - Tampon DTU visible et énorme
#   - Aucun chevauchement texte/texte ou texte/trait
#   - Charte stricte respectée
#   - Annotations manuscrites Sunrise lisibles
#   - Valeurs cotées attribuées à la bonne source
```

### Cas B : adapter un design existant

1. Lire le HTML du template à modifier
2. Faire un `Edit` ciblé (pas de réécriture from scratch sauf si nécessaire)
3. Re-render + Read PNG
4. Itérer jusqu'au "zero overlap"

### Cas C : nouveau format (story, square, LinkedIn paysage)

Les formats sont définis dans `src/render.js` (objet `FORMATS`) :
- `ig-portrait-1080-1350` (1080×1350, 4:5) ⭐ format principal
- `ig-square-1080` (1080×1080)
- `ig-story-1080-1920` (1080×1920, 9:16)
- `linkedin-landscape-1200-627` (1200×627)
- `tiktok-cover-1080-1920` (1080×1920, 9:16)

Pour ajouter un format : créer le sous-dossier dans `templates/<format>/`, mettre un `.html` avec les bonnes dimensions inline, puis render.

---

## 🗣️ 7. Comment parler à Claude Code pour produire un design

**Bon prompt** (ce qu'on veut) :

> « Crée 4 carrousels DTU 25.41 plâtrerie en style NAVY. Source : WebFetch Batirama + Pladur, valeurs validées : BA13/BA15/BA18, entraxe ossature 60 cm, vis 30 cm max sur métal, longueur +1 cm sur épaisseur totale. Numérotation : autaf-84 à 87. Garde le CSS du modèle autaf-76 à 79. Anti-invention strict. »

**Mauvais prompt** (ce qu'on évite) :

> « Fais-moi des belles slides sur le DTU 25.41 plâtrerie. »
>
> *(trop vague → Claude va inventer des chiffres pour combler les blancs)*

**Mots-clés qui marchent bien avec ce stack** :
- "anti-invention strict" → Claude n'inventera pas de chiffres
- "respecter charte AUTAF" → applique la palette stricte
- "comme autaf-76" → copie le CSS exactement
- "pas de chevauchement, 8px+ de marge" → soin layout
- "logo footer fill #FFE72B" (navy) ou "fill #241B5D" (yellow)
- "validation visuelle par Read PNG" → Claude vérifie le rendu

**Phrases-types pour itérer un design** :
- « Le texte X chevauche le trait Y → déplace en y=... »
- « La cote rouge est trop près de la flèche → cartouche blanc à bordure rouge »
- « Trop de jaune partout → garde le jaune pour les valeurs uniquement, traits en blanc »
- « DTU 39 : pas de chiffres précis sources publiques → reformule en principes »

---

## 📚 8. Fichiers à lire dans l'ordre

1. **`ONBOARDING-CLAUDE.md`** (ce fichier) — onboarding
2. **`CLAUDE.md`** — instructions Claude détaillées
3. **`wiki/INDEX.md`** — wiki Karpathy navigation
4. **`wiki/schema.md`** — taxonomie complète (formats, naming, brand.json)
5. **`wiki/notes/brand-autaf.md`** — charte couleurs/fonts complète
6. **`wiki/notes/pattern-*.md`** — 3 patterns esthétiques validés
7. **`log.md`** — journal chronologique (utile pour voir l'historique des décisions)

---

## ⚙️ 9. Commandes essentielles

```bash
# Render un template précis
node src/render.js --brand autaf --template autaf-76

# Render tout AUTAF
node src/render.js --brand autaf

# Render un format précis
node src/render.js --brand autaf --format ig-portrait-1080-1350

# Voir le dashboard
curl http://localhost:8940/

# Lister les brands
curl http://localhost:8940/api/brands

# Re-builder le tarball d'export (pour distribuer ailleurs)
bash scripts/build-export.sh

# Restart le service
systemctl restart cg-design-api

# Logs
journalctl -u cg-design-api -f
```

---

## 🎯 10. Exemple d'interaction réussie

**Philippe** : « Fais-moi 4 carrousels DTU 13.3 dallage béton en yellow »

**Claude Code idéal** :
1. WebSearch « DTU 13.3 dallage béton épaisseur armatures joints »
2. WebFetch sur Batirama + Mortier-Matériaux pour les chiffres
3. Construit un brief : 120/130/150 mm selon usage, armatures 0,2%, joints retrait > 240 m², coupe scie < 48h
4. Présente le brief à Philippe pour validation
5. Code 4 fichiers `autaf-{128..131}-yellow-dallage-{1..4}.html` en copiant strictement le CSS de autaf-80 à 83
6. Render → 4 PNG dans output/
7. Read PNG → vérifie absence de chevauchement
8. Si chevauchement : Edit ciblé + re-render
9. Une fois propre : confirme à Philippe avec recap des valeurs sourcées

---

## 🚨 11. Erreurs classiques à ne PAS répéter

| Erreur | Conséquence | Évitement |
|--------|-------------|-----------|
| Inventer un chiffre BTP | Décrédibilise le compte pro | WebFetch source officielle systématique |
| Mélanger DTU + RE2020 + CEE | Glissement normatif faux | Attribution explicite par référence |
| Cyan / bleu clair / gradient flou | Hors charte AUTAF | Palette stricte navy/jaune/blanc/rouge |
| Chip DTU trop petite (12px) | Pas de signal de marque | Tampon 50-54px minimum, fond accent + ombre |
| 2 textes au même y= | Chevauchement | Décaler de 16px+ ou ré-organiser le layout |
| « plafonnier » à côté de la légende | Collision visuelle | Annotations à l'écart, leader-line si besoin |
| Slide récap sans `.why` détaillée | Slide pauvre | Toujours expliquer pourquoi la règle existe |

---

## 🤝 12. Contact

Sur ce stack, Philippe (philippegagnonp@gmail.com) est le décideur charte + factuel.
Pour toute question normative BTP, lui présenter le brief tabulaire AVANT codage.

**Mantra du stack** : *« On n'a pas le droit à l'erreur. »*

Bon code 🎨
