#!/usr/bin/env bash
# cg-design — build the export tarball that other VPSes can curl + extract
# Usage: bash scripts/build-export.sh
#
# Output: _export/cg-design-latest.tar.gz + _export/cg-design-<date>.tar.gz

set -euo pipefail
cd "$(dirname "$0")/.."

EXPORT_DIR="_export"
TS=$(date +%Y%m%d-%H%M)
DATED="cg-design-${TS}.tar.gz"
LATEST="cg-design-latest.tar.gz"

mkdir -p "$EXPORT_DIR"

# Files to exclude
EXCLUDES=(
  --exclude="cg-design/node_modules"
  --exclude="cg-design/output"
  --exclude="cg-design/_export"
  --exclude="cg-design/.git"
  --exclude="cg-design/*.log"
)

echo "→ Build tarball ${DATED}..."
# We tar from /opt/stack/ so the inner dir is "cg-design/"
( cd .. && tar czf "$(pwd)/cg-design/${EXPORT_DIR}/${DATED}" "${EXCLUDES[@]}" cg-design/ )

# latest pointer
( cd "$EXPORT_DIR" && cp -f "${DATED}" "${LATEST}" )

SIZE=$(du -h "${EXPORT_DIR}/${DATED}" | cut -f1)
echo "✓ ${EXPORT_DIR}/${DATED} (${SIZE})"
echo "✓ ${EXPORT_DIR}/${LATEST} (alias)"
echo
echo "URL : http://$(curl -s ifconfig.me 2>/dev/null || echo '<vps-ip>'):8940/export/${LATEST}"
