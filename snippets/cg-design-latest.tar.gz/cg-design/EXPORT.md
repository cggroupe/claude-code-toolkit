# Installation cg-design sur un autre VPS

Procédure d'import depuis un VPS source qui héberge déjà cg-design (ex. VPS design AUTAF 72.62.178.237).

---

## Méthode recommandée : tarball HTTP

### Sur le VPS source (déjà fait)

Le tarball est servi par `cg-design-api` à l'URL :

```
http://<ip-source>:8940/export/cg-design-latest.tar.gz
```

(Sur le VPS source : `http://72.62.178.237:8940/export/cg-design-latest.tar.gz`)

### Sur le VPS de destination

```bash
# 1. Préparer le dossier cible
mkdir -p /opt/stack && cd /opt/stack

# 2. Télécharger + extraire
curl -L "http://72.62.178.237:8940/export/cg-design-latest.tar.gz" -o cg-design.tar.gz
tar xzf cg-design.tar.gz
rm cg-design.tar.gz

# 3. Installer
cd /opt/stack/cg-design
bash install.sh
```

L'install.sh va :
- Vérifier Node.js 20+
- Installer Inter + Inter Display si manquants
- Installer Puppeteer (`npm install puppeteer@^24.0.0`)
- Setup le service systemd `cg-design-api` (port 8940 par défaut)
- Ouvrir UFW si actif
- Faire un premier render pour valider

Durée totale : ~3-5 minutes selon bande passante.

---

## Options install.sh

```bash
bash install.sh --target /opt/cg-design   # autre dossier d'install
bash install.sh --port 9940               # autre port
bash install.sh --no-systemd              # juste l'install, pas de service
```

---

## Que contient le tarball

```
cg-design/
├── README.md, CLAUDE.md, EXPORT.md, log.md, package.json, install.sh
├── brands/                  ← brand.json + logos pour chaque marque
├── templates/               ← HTML/CSS par format
├── src/                     ← render.js + server.js
├── wiki/                    ← documentation Karpathy (INDEX + schema + notes)
└── (output/ vide, à régénérer après install)
```

**Exclus du tarball** : `node_modules/` (réinstallé par install.sh) et `output/` (vide à l'arrivée).

---

## Côté VPS de destination, pour Claude Code

Une fois installé, Claude Code lit automatiquement :
- `/opt/stack/cg-design/CLAUDE.md` → instructions pour générer un design
- `/opt/stack/cg-design/wiki/INDEX.md` → wiki Karpathy navigation
- `/opt/stack/cg-design/wiki/notes/` → notes atomiques par pattern et marque

Pour customiser une marque sur le nouveau VPS (ex. AUTAF avec plus d'infos) :
1. Éditer `brands/autaf/brand.json` (stats, ton, ICP…)
2. Mettre à jour `wiki/notes/brand-autaf.md` avec les nouvelles infos
3. Adapter les templates `templates/ig-portrait-1080-1350/autaf-*.html` si besoin
4. Re-render : `node src/render.js --brand autaf`
5. Vérifier sur le dashboard

---

## Mise à jour incrémentale (re-import)

Pour tirer une nouvelle version depuis le VPS source sans tout casser :

```bash
cd /opt/stack
mv cg-design cg-design.bak.$(date +%Y%m%d)
curl -L "http://72.62.178.237:8940/export/cg-design-latest.tar.gz" | tar xz
cp -r cg-design.bak.*/brands cg-design/   # garde tes brand.json customisés
cp -r cg-design.bak.*/output cg-design/   # garde tes designs rendus si tu veux
systemctl restart cg-design-api
```

---

## Troubleshooting

### Le tarball ne télécharge pas
Vérifier que le service `cg-design-api` tourne sur le VPS source et que UFW autorise 8940 :
```bash
# sur le VPS source
systemctl status cg-design-api
ufw status | grep 8940
curl -I http://localhost:8940/export/cg-design-latest.tar.gz
```

### Puppeteer crashe au render
Souvent un manque de libs Chromium. Sur Ubuntu :
```bash
apt-get install -y libnss3 libatk1.0-0 libatk-bridge2.0-0 libdrm2 \
  libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 \
  libgbm1 libpango-1.0-0 libcairo2 libasound2t64
```

### Polices Inter pas chargées (rendu fallback)
```bash
fc-list | grep -i "inter display"
# si rien, relance l'install.sh ou télécharge manuellement Inter v4.1
fc-cache -fv
```
